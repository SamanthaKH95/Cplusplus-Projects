/*
 *  main.cpp
 *
 *  COSC 051 Spring 2019
 *  Project #5
 *
 *  Due on: April 30, 2019
 *  Author: skh50
 *
 *
 *  In accordance with the class policies and Georgetown's
 *  Honor Code, I certify that, with the exception of the
 *  class resources and those items noted below, I have neither
 *  given nor received any assistance on this project.
 *
 *  References not otherwise commented within the program source code.
 *  Note that you should not mention any help from the TAs, the professor,
 *  or any code taken from the class textbooks.
 */


#include <string>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <cstdlib>
#include <cmath>
#include <stdio.h>
#include <iostream>
using namespace std;

// local file path on my computer /Users/sam/Downloads/P3West.dat
// local file path on my computer /Users/sam/Downloads/P3South.dat
// local file path on my computer /Users/sam/Downloads/P3North.dat
// local file path on my computer /Users/sam/Downloads/P3East.dat
// local file path on my computer /Users/sam/Downloads/P3Other.dat
// local file path on my computer /Users/sam/Downloads/P3All.dat

/****************************************************************************
 ****************************************************************************
 **                                                                        **
 **                          GLOBAL CONSTANTS                              **
 **                                                                        **
 ****************************************************************************
 ****************************************************************************/

const double B_PACK_LOAD = 0.065;
const double B_PER_LB_MILE = 0.0011;
const double W_PACK_LOAD = 0.256;
const double W_PER_LB_MILE = 0.0011;
const double C_PACK_LOAD = 0.459;
const double C_PER_LB_MILE = 0.0012;
const int MIN_DRIVING_DISTANCE = 1;
const int MAX_DRIVING_DISTANCE = 3200;
const int WEIGHT_LOWER_BOUND = 1200;
const int WEIGHT_UPPER_BOUND = 18000;
const int MAX_PIANOS = 3;
const int MIN_PIANOS = 0;
const double STAIRS_SURCHARGE_RATE = 132;
const int NO_STAIRS_PIANO_SURCHARGE = 275;
const int ONE_STAIRS_PIANO_SURCHARGE = 575;
const int TWO_STAIRS_PIANO_SURCHARGE = 1075;

const string ERROR_FILE_OPEN = "ERROR: File open error, please check path and name of: ";
const string SUCCESS_FILE_OPEN = "File opened successfully for input: ";


/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 class MoveOrder declaration                     **
 **                                                                 **
 **            This code is provided to students                    **
 **            in COSC 051 Spring 2019 to use in                    **
 **            part or in total for class projects.                 **
 **            Students may use this code as their                  **
 **            own, without any attribution.                        **
 **                                                                 **
 *********************************************************************
 *********************************************************************/

/**
 * <P>A class for storing all information relating to one move
 * estimate for Bubba Hotep Moving and Storage, Inc. (BHMSI).</P>
 *
 * <P>MoveOrder objects shall store any values entered or input from
 * a data file.  NOTE: this means that MoveOrder objects may store
 * values that are NOT valid based upon BHMSI business rules.  The
 * class has several accessor methods that may be called to determine
 * if a specific object contains any invalid values.</P>
 *
 * @author W. A. Woods (waw23 at georgetown dot edu)
 * @version 1.1, 2019/03/17
 * @version 1.2, 2019/04/08
 * @version 2.1, 2019/04/09
 *
 */

class MoveOrder
{
    //overloaded stream insertion operator
    friend ostream& operator<<( ostream &os, const MoveOrder &rhsObj );
    
    //overloaded stream extraction operator
    friend istream& operator>>( istream &is, MoveOrder &rhsObj );
    
private:
    //the data members below are required (you may change identifiers)
    //there is no need for additional data members
    int estimateYear;     /*!< the year the estimate was prepared */
    int estimateMonth;    /*!< the month the estimate was prepared */
    int estimateDay;      /*!< the day the estimate was prepared */
    int moveYear;         /*!< the year the move is scheduled to occur */
    int moveMonth;        /*!< the month the move is scheduled to occur */
    int moveDay;          /*!< the day the move is scheduled to occur */
    char type;            /*!< the move type */
    int givenDistance;    /*!< the distance value that was in the data file */
    int distance;         /*!< the distance value to use, may have been adjusted from given value */
    int weight;           /*!< the weight of contents to move */
    int givenPianos;      /*!< the pianos value that was in the data file */
    int pianos;           /*!< the pianos value to use, may have been adjusted from given value */
    char stairsOrigin;         /*!< are there > 15 stairs at the origin? */
    char stairsDestination;    /*!< are there > 15 stairs at the destination? */
    string estimateNumber;     /*!< the estimate number */
    string region;             /*!< the region of the move origin */
    string customerNameEmail;  /*!< the customer's name and email address */
    
    MoveOrder *next;      /*!< P5 - the address of the next MoveOrder object in the linked-list */
    
public:
    //required constructors
    //you may change parameter identifiers, but the order and types of the parameters
    //must be the same as shown in the prototypes
    
    // destructor
    ~MoveOrder();   /*!< P5 - may NOT be implemented in-line (new mutator)  */
    
    //default constructor
    MoveOrder();
    
    //constructor with parameters
    MoveOrder(int eYYYY, int eMM, int eDD, int mYYYY, int mMM, int mDD,
              char typ, int dst, int wgt, int pno, char sO, char sD,
              string eNum, string reg, string nameEmail, MoveOrder *ptr = NULL);
    
    //copy constructor
    MoveOrder( const MoveOrder &otherObj );
    
    //overloaded assignment operator
    MoveOrder& operator=( const MoveOrder &otherObj );
    
    //required basic mutator functions, in-line implementation is OK for most
    //you may change parameter identifiers but NOT the function identifiers
    void setEstimateYear( int value ) { estimateYear = value; } /*!< in-line mutator  */
    void setEstimateMonth( int value ) { estimateMonth = value; } /*!< in-line mutator  */
    void setEstimateDay( int value ) { estimateDay = value; } /*!< in-line mutator  */
    void setMoveYear( int value ) { moveYear = value; } /*!< in-line mutator  */
    void setMoveMonth( int value ) { moveMonth = value; } /*!< in-line mutator  */
    void setMoveDay( int value ) { moveDay = value; } /*!< in-line mutator  */
    void setType( char value ) { type = value; } /*!< in-line mutator  */
    
    void setDistance( int value ); // given value may be adjusted, may NOT implement in-line
    
    void setWeight( int value ) { weight = value; } /*!< in-line mutator  */
    
    void setPianos( int value );  // given value may be adjusted, may NOT implement in-line
    
    void setStairsOrigin( char value ) { stairsOrigin = value; } /*!< in-line mutator  */
    void setStairsDestination( char value ) { stairsDestination = value; } /*!< in-line mutator  */
    void setEstimateNumber( string value ) { estimateNumber = value; } /*!< in-line mutator  */
    void setRegion( string value ) { region = value; } /*!< in-line mutator  */
    void setCustomerNameEmail( string value ) {customerNameEmail = value;} /*!< in-line mutator  */
    
    void setNext(MoveOrder *ptr) {next = ptr;};  /*!< P5 - may be implemented in-line (new mutator)  */
    
    //required basic accessor functions, in-line implementation
    //you may change parameter identifiers but NOT the function identifiers
    int getEstimateYear() const { return estimateYear; } /*!< in-line accessor  */
    int getEstimateMonth() const { return estimateMonth; } /*!< in-line accessor  */
    int getEstimateDay() const { return estimateDay; } /*!< in-line accessor  */
    int getMoveYear() const { return moveYear; } /*!< in-line accessor  */
    int getMoveMonth() const { return moveMonth; } /*!< in-line accessor  */
    int getMoveDay() const { return moveDay; } /*!< in-line accessor  */
    char getType() const { return type; } /*!< in-line accessor  */
    int getGivenDistance() const { return givenDistance; } /*!< in-line accessor  */
    int getDistance() const { return distance; } /*!< in-line accessor  */
    int getWeight() const { return weight; } /*!< in-line accessor  */
    int getGivenPianos() const { return givenPianos; } /*!< in-line accessor  */
    int getPianos() const { return pianos; } /*!< in-line accessor  */
    char getStairsOrigin() const { return stairsOrigin; } /*!< in-line accessor  */
    char getStairsDestination() const { return stairsDestination; } /*!< in-line accessor  */
    string getEstimateNumber() const { return estimateNumber; } /*!< in-line accessor  */
    string getRegion() const { return region; } /*!< in-line accessor  */
    string getCustomerNameEmail() const { return customerNameEmail; } /*!< in-line accessor  */
    
    MoveOrder* getNext() {return next;}  /*!< P5 - may be implemented in-line (new accessor)  */
    
    //required accessor functions that perform more detailed calculations
    //you may change parameter identifiers but NOT the function identifiers
    
    //these functions perform validation of the object's data values
    //same validation rules as project 1, project 2, and project 3
    //answer is set to true if validation test passes, false otherwise
    //message is set to the error message for that test
    void validDates( bool &answer, string &message, bool &tooSoon, bool &tooLate ) const;
    void validType( bool &answer, string &message ) const;
    void validDistance( bool &answer, string &message ) const;
    void validWeight( bool &answer, string &message ) const;
    void validPianoCount( bool &answer, string &message ) const;
    void validStairsOrigin( bool &answer, string &message ) const;
    void validStairsDestination( bool &answer, string &message ) const;
    
    //this function calls each of the other validation methods to
    //determine an overall validity check for this object
    //NOTE: the complete code for this method is given
    void validEstimate( bool &, string &, int & ) const;
    
    //this function outputs values and error messages (if applicable) for this object
    //NOTE: the complete code for this method is given
    void printWithMessages( ostream &os = cout ) const;
    
    //this function returns the calculated cost of this move object according to the
    //same calculation rules as project 1, project 2, and project 3
    double getTotalCost() const;
    
    
    //OPTIONAL
    //if you add any methods they should should go here
    //you may not add any member functions that supercede the required member functions
    //or the stand-alone functions, anything you add should enhance your solution
    //this function returns the full name of the move type:
    //     "Basic     " for b or B
    //     "Wall Pack " for w or W
    //     "Complete  " for c or C
    string getTypeName() const;
    
    
}; //END declaration class MoveOrder

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Overloaded Stream Insertion                     **
 **                         Operator                                **
 *********************************************************************
 *********************************************************************/
ostream& operator<<( ostream &os, const MoveOrder &rhsObj )
{
    //have to overload because cin and cout are members of istream and ostream classes
    //it will not compile unless operator was overloaded to become a member of the left
    //hand side object class. Also this solves member assignment and memory issues
    
    
    //stream insertion operator is to cout things
    char slash = '/';
    bool answer = true;
    string message = " ";
    int errors = 0; //accumulator
    //take formatting from other project
    //outputting the headings
    
    cout << setfill(' ');
    cout << setw(4) << " " << rhsObj.estimateYear << slash << setfill('0') << setw(2)
    << rhsObj.estimateMonth<< slash << setw(2) << rhsObj.estimateDay;
    cout << setfill(' ') << setw(10) << rhsObj.moveYear << slash << setfill('0') << setw(2)
    << rhsObj.moveMonth << slash << setw(2) << rhsObj.moveDay;
    cout << setfill(' ') << setw(9) << rhsObj.type;
    cout << setw(11) << rhsObj.distance;
    cout << setw(10) << rhsObj.weight;
    cout << setw(7) << rhsObj.pianos;
    cout << setw(8) << rhsObj.stairsOrigin;
    cout << setw(5) << rhsObj.stairsDestination;
    cout << setw(12) << rhsObj.getEstimateNumber();
    cout << setw(11) << rhsObj.getTotalCost();
    
    rhsObj.validEstimate(answer, message, errors);
    if (answer==false)
    {
        cout << "       E";
    }
    
    return os;
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Overloaded Stream Extraction                    **
 **                         Operator                                **
 *********************************************************************
 *********************************************************************/
istream& operator>>( istream &is, MoveOrder* &rhsObj )
{
    
    //stream extraction operator is to cin things for processing and storage
    //temp variables
    string State;
    string Region;
    string UniqueID;    //string with no spaces
    string NameAndEmail; //with space
    int DrivingDistance;
    int TotalWeightLBS;
    int NumPianos;
    char MoveType;
    char MoreThan15StairsOrigin;
    char MoreThan15StairsDest;
    int ESTyear = 0, ESTmonth= 0, ESTday= 0; //to store estimate date components
    int Moveyear = 0, Movemonth= 0, Moveday= 0; //to store estimate date components
    char slash = '?'; //to store slash in between date components
    
    is >> UniqueID >> ESTyear >> slash >> ESTmonth >> slash >> ESTday >>
    Moveyear >> slash >> Movemonth >> slash >> Moveday >> MoveType >>
    DrivingDistance >> TotalWeightLBS >> NumPianos >> MoreThan15StairsOrigin >>
    MoreThan15StairsDest >> State >> Region;
    getline(is, NameAndEmail);
    
    
    rhsObj->setEstimateYear(ESTyear);
    rhsObj->setEstimateMonth(ESTmonth);
    rhsObj->setEstimateDay(ESTday);
    rhsObj->setMoveYear(Moveyear);
    rhsObj->setMoveMonth(Movemonth);
    rhsObj->setMoveDay(Moveday);
    rhsObj->setType(MoveType);
    rhsObj->setDistance(DrivingDistance);
    rhsObj->setWeight(TotalWeightLBS);
    rhsObj->setPianos(NumPianos);
    rhsObj->setStairsOrigin(MoreThan15StairsOrigin);
    rhsObj->setStairsDestination(MoreThan15StairsDest);
    rhsObj->setEstimateNumber(UniqueID);
    rhsObj->setRegion(Region);
    rhsObj->setCustomerNameEmail(NameAndEmail);
    
    return is;
}


/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Default Constructor                             **
 *********************************************************************
 *********************************************************************/
MoveOrder::MoveOrder()
{
    //assigns all data members default values
    //cout << "default constructor start\n";
    estimateYear = 2018;
    estimateMonth = 1;
    estimateDay = 1;
    moveYear = 2018;
    moveMonth = 1;
    moveDay = 1;
    type = 'C';
    distance = 0;
    weight = 0;
    pianos = 0;
    stairsOrigin = 'n';
    stairsDestination = 'n';
    estimateNumber = ' ';
    region = "Other";
    customerNameEmail = ' ';
    //cout << "Default constructor end\n";
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Constructor With Parameters                     **
 *********************************************************************
 *********************************************************************/
MoveOrder::MoveOrder(int eYYYY, int eMM, int eDD, int mYYYY, int mMM, int mDD,
                     char typ, int dst, int wgt, int pno, char sO, char sD,
                     string eNum, string reg, string nameEmail, MoveOrder *ptr)
{
    //Sets all data members to values passed in to its parameters, the code in
    //this constructor shall call CLASS SETTER METHODS to make the actual
    //value initilization for each data member.
    
    setEstimateYear(eYYYY);
    setEstimateMonth(eMM);
    setEstimateDay(eDD);
    setMoveYear(mYYYY);
    setMoveMonth(mMM);
    setMoveDay(mDD);
    setType(typ);
    setDistance(dst);
    setWeight(wgt);
    setPianos(pno);
    setStairsOrigin(sO);
    setStairsDestination(sD);
    setEstimateNumber(eNum);
    setRegion(reg);
    setCustomerNameEmail(nameEmail);
    
    
    
}


/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Copy Constructor                                **
 *********************************************************************
 *********************************************************************/
MoveOrder::MoveOrder(const MoveOrder &otherObj)
{
    //called when a new object is created and initialized with the data
    //of another object of the same class
    
    this->setEstimateYear(otherObj.estimateYear);
    this->setEstimateMonth(otherObj.estimateMonth);
    this->setEstimateDay(otherObj.estimateDay);
    this->setMoveYear(otherObj.moveYear);
    this->setMoveMonth(otherObj.moveMonth);
    this->setMoveDay(otherObj.moveDay);
    this->setType(otherObj.type);
    this->setDistance(otherObj.distance);
    this->setWeight(otherObj.weight);
    this->setPianos(otherObj.pianos);
    this->setStairsOrigin(otherObj.stairsOrigin);
    this->setStairsDestination(otherObj.stairsDestination);
    this->setEstimateNumber(otherObj.estimateNumber);
    this->setRegion(otherObj.region);
    this->setCustomerNameEmail(otherObj.customerNameEmail);
    
}


/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Overloaded Assignment                           **
 **                       Operator                                  **
 *********************************************************************
 *********************************************************************/
MoveOrder& MoveOrder::operator=(const MoveOrder &otherObj)
{
    /*Sets all data members to the same values of an existing MoveOrder object.
     
     The overloaded assignment operator returns a reference to the left hand side operand
     (the object being copied to). Before making any changes to the object being copied
     to the overloade assignment operator must first test to ensure it is not an attempt
     at self-assignment. If it is self-assignment,
     then nothing should happen except for the return.
     
     If it is NOT self-assignment, then code in this constructor shall call class setter methods
     to make the actual value update for each data member.*/
    
    //checking for self assignment
    if (this != &otherObj)
    {
        
        
        //using setter methods
        setEstimateYear(otherObj.estimateYear);
        setEstimateMonth(otherObj.estimateMonth);
        setEstimateDay(otherObj.estimateDay);
        setMoveYear(otherObj.moveYear);
        setMoveMonth(otherObj.moveMonth);
        setMoveDay(otherObj.moveDay);
        setType(otherObj.type);
        setDistance(otherObj.distance);
        setWeight(otherObj.weight);
        setPianos(otherObj.pianos);
        setStairsOrigin(otherObj.stairsOrigin);
        setStairsDestination(otherObj.stairsDestination);
        setEstimateNumber(otherObj.estimateNumber);
        setRegion(otherObj.region);
        setCustomerNameEmail(otherObj.customerNameEmail);
    }
        return *this;
    
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 SetDistance                                     **
 *********************************************************************
 *********************************************************************/

void MoveOrder::setDistance( int value )
{
    /*The givenDistance data member is set to the value parameter. The distance data member is set
     to the value parameter if it is at least 1 (the minimum distance). If the value parameter is
     less than 1, then the distance data member is set to 1. This adjustment is made silently
     meaning that there is no error message or other notification.*/
    
    if (value >= MIN_DRIVING_DISTANCE) //min driving distance = 1
    {
        givenDistance = value;
        distance = value;
    }
    else if (value < MIN_DRIVING_DISTANCE)
    {
        givenDistance = value;
        distance = MIN_DRIVING_DISTANCE;
    }
    
    
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 SetPiano                                        **
 *********************************************************************
 *********************************************************************/

void MoveOrder::setPianos(int value)
{
    /*The givenPianos data member is set to the value parameter. The pianos data member is set
     to the value parameter if it is at least zero. If the value parameter is less than zero,
     then the pianos data member is set to zero. This adjustment is made silently meaning that
     there is no error message or other notification.*/
    
    if (value >= MIN_PIANOS) //min pianos = 0
    {
        givenPianos = value;
        pianos = value;
    }
    else if (value < MIN_PIANOS)
    {
        givenPianos = value;
        pianos = MIN_PIANOS;
    }
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **these functions perform validation of the object's data values   **
 **same validation rules as project 1, project 2, and project 3     **
 **answer is set to true if validation test passes, false otherwise **
 **message is set to the error message for that test                **
 *********************************************************************
 *********************************************************************/


void MoveOrder::validDates( bool &answer, string &message, bool &tooSoon, bool &tooLate ) const
{
    
    //cout << "validdates method start\n";
    //dummy variable since function is const
    //cout << "equated\nmove month: " << this << endl;
    if (moveMonth < estimateMonth)
    {
        
        int tempmovemonth = moveMonth+12;
    }
    if (moveMonth-estimateMonth < 2)
    {
        
        tooSoon = true;
        answer = false;
        tooLate = false;
        message = "\nERROR: The move date is too soon after the estimate date.";
    }
    else if (moveMonth-estimateMonth > 6)
    {
        
        tooLate = true;
        tooSoon = false;
        answer= false;
        message = "\nERROR: The move date is too long after the estimate date.";
    }
}


void MoveOrder::validType( bool &answer, string &message ) const
{
    if (type != 'B' && type != 'b' && type != 'W' && type != 'w' &&
        type != 'C' && type != 'c')
    {
        message = "\nERROR: Move type invalid";
        answer = false;
    }
}
void MoveOrder::validDistance( bool &answer, string &message ) const
{
    if (distance > MAX_DRIVING_DISTANCE)
    {
        message = "\nERROR: Distance exceeded max distance of 3200";
        answer = false;
    }
}
void MoveOrder::validWeight( bool &answer, string &message ) const
{
    int DoubleDistance;
    int MinWeight;
    //computing min weight value
    DoubleDistance = 2 * distance;
    if (DoubleDistance < WEIGHT_LOWER_BOUND)
    {
        MinWeight = WEIGHT_LOWER_BOUND;
    }
    else
    {
        MinWeight = DoubleDistance;
    }
    if(weight < MinWeight)
    {
        message = "\nERROR: Weight entered less than minimum allowed";
        answer = false;
        
    }
    if (weight > WEIGHT_UPPER_BOUND)
    {
        message = "\nERROR: Weight entered exceeds max of 18000";
        answer = false;
        
    }
}
void MoveOrder::validPianoCount( bool &answer, string &message ) const
{
    if (pianos > MAX_PIANOS)
    {
        message = "\nERROR: Maximum number of pianos exceeded.";
        answer = false;
    }
}
void MoveOrder::validStairsOrigin( bool &answer, string &message ) const
{
    if (stairsOrigin != 'y' && stairsOrigin != 'Y' &&
        stairsOrigin != 'n' && stairsOrigin != 'N')
    {
        message = "\nERROR: answer of stairs at origin invalid";
        answer= false;
    }
    
}
void MoveOrder::validStairsDestination( bool &answer, string &message ) const
{
    if (stairsDestination != 'y' && stairsDestination != 'Y' &&
        stairsDestination != 'n' && stairsDestination != 'N')
    {
        message = "\nERROR: answer of stairs at destination invalid";
        answer =false;
    }
    
}


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +                                                                          +
 +                  MoveOrder class validEstimate method                    +
 +                                                                          +
 +                                                                          +
 +                 This code is provided to students                        +
 +                 in COSC 051 Spring 2019 to use in                        +
 +                 part or in total for class projects.                     +
 +                 Students may use this code as their                      +
 +                 own, without any attribution.                            +
 +                                                                          +
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

//this function calls each of the other validation methods to
//determine an overall validity check for this object
//NOTE: the complete code for this method is given

void MoveOrder::validEstimate( bool &answer, string &message, int &errorCount ) const
{
    //cout << "validestimate method start\n";
    // an estimate is valid overall if ALL of the individual validation tests pass
    
    // assume estimate is valied prior to testing
    errorCount = 0;
    
    // define variables to store error messages from the individual validation tests
    string messageDates = "";
    string messageType = "";
    string messageDistance = "";
    string messageWeight = "";
    string messagePiano = "";
    string messageStairsO = "";
    string messageStairsD = "";
    
    string overallMessage = "";  // store messages from all individual tests
    bool testGood = true;        // reuse this for each individual test function call
    bool overallGood = true;     // this is overall record validity
    bool moveTooSoon = false;    // true if there is not enough time between the estimate/move
    bool moveTooLate = false;    // true if there is too much enough time between the estimate/move
    
    // combine results from the individual validation test methods
    //     - call each individual validation test
    //     - update variable to keep count of errors found
    //     - update overallGood boolean
    //     - update overallMessage string
    
    validDates( testGood, messageDates, moveTooSoon, moveTooLate );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageDates;
    
    validType( testGood, messageType );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageType;
    
    validDistance( testGood, messageDistance );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageDistance;
    
    validWeight( testGood, messageWeight );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageWeight;
    
    validPianoCount( testGood, messagePiano );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messagePiano;
    
    validStairsOrigin( testGood, messageStairsO );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageStairsO;
    
    validStairsDestination( testGood, messageStairsD );
    if (!testGood)
        errorCount++;
    overallGood = overallGood && testGood;
    overallMessage += messageStairsD;
    
    if (errorCount > 0)
    {
        overallMessage += "\n\tContact customer to resolve issues: ";
        overallMessage += customerNameEmail;
        overallMessage += "\n";
    }
    
    // update the parameters with final values that will be returned
    answer = overallGood;
    message = overallMessage;
    
} // END validEstimate method for MoveOrder class



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +                                                                          +
 +                MoveOrder class printWithMessages method                  +
 +                                                                          +
 +                                                                          +
 +                 This code is provided to students                        +
 +                 in COSC 051 Spring 2019 to use in                        +
 +                 part or in total for class projects.                     +
 +                 Students may use this code as their                      +
 +                 own, without any attribution.                            +
 +                                                                          +
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */


//this function outputs values and error messages (if applicable) for this object
//NOTE: the complete code for this method is given

void MoveOrder::printWithMessages( ostream &os ) const
{
    // local variables that are necessary to call the validEstimate method
    string errMsgs = "";
    bool allOK = true;
    int totalErrors = 0;
    
    // call the validEstimate member function
    // this will store any error messages in the
    // local variable errMsgs, it will also store
    // zero (false) in the local variable allOK if
    // the object has any errors (fails any of the
    // various validation tests)
    validEstimate(allOK, errMsgs, totalErrors);
    
    //cout << "Estimates valid\n";
    // send the object to the stream defined in the parameter list
    os << *this;
    
    // if any validation tests failed, then also print out
    // the error messages
    if (!allOK)
    {
        os << endl;
        os << errMsgs;
    }
    
    os << endl;
    //cout << "printwithmessages end\n";
    
} // END printWithMessages method for MoveOrder class

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Total Cost                                      **
 *********************************************************************
 *********************************************************************/

double MoveOrder::getTotalCost() const
{
    
    double TotalCost = 0;
    double PianoSurcharge = 0;
    double StairsSurcharge = 0;
    int SetofStairs = 0;
    
    // calculating total cost
    //calculating total number of stairs exceeding 15 steps
    if (stairsOrigin == 'Y' || stairsOrigin == 'y')
    {
        SetofStairs++;
    }
    if (stairsDestination == 'Y' || stairsDestination == 'y')
    {
        SetofStairs++;
    }
    
    
    StairsSurcharge = STAIRS_SURCHARGE_RATE * SetofStairs;
    
    //figuring out piano surcharge based on sets of stairs
    if (SetofStairs == 0)
    {
        PianoSurcharge = pianos * NO_STAIRS_PIANO_SURCHARGE;
    }
    if (SetofStairs == 1)
    {
        PianoSurcharge = pianos * ONE_STAIRS_PIANO_SURCHARGE;
    }
    if (SetofStairs == 2)
    {
        PianoSurcharge = pianos * TWO_STAIRS_PIANO_SURCHARGE;
    }
    
    //final calculations of cost depending on move type
    if (type == 'B' || type == 'b')
    {
        TotalCost = (B_PACK_LOAD*weight) +
        (B_PER_LB_MILE*weight*distance) + StairsSurcharge +
        PianoSurcharge;
        
    }
    
    if (type == 'C' ||type == 'c')
    {
        TotalCost = (C_PACK_LOAD*weight) +
        (C_PER_LB_MILE*weight*distance) + StairsSurcharge +
        PianoSurcharge;
        
    }
    
    if (type == 'W'||type == 'w')
    {
        TotalCost = (W_PACK_LOAD*weight) +
        (W_PER_LB_MILE*weight*distance) + StairsSurcharge +
        PianoSurcharge;
        
    }
    return TotalCost;
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 GetType                                         **
 *********************************************************************
 *********************************************************************/

string MoveOrder::getTypeName() const
{
    string name = "invalid";
    
    if (type == 'B' || type == 'b')
    {
        name = "Basic";
        
    }
    
    if (type == 'C' ||type == 'c')
    {
        name = "Complete";
        
    }
    
    if (type == 'W'||type == 'w')
    {
        name = "Wall Pack";
    }
    
    return name;
}


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 ++                                                                        ++
 ++                      MoveOrder class destructor                        ++
 ++                                                                        ++
 ++                 This code is provided to students                      ++
 ++                 in COSC 051 Spring 2019 to use in                      ++
 ++                 part or in total for class projects.                   ++
 ++                 Students may use this code as their                    ++
 ++                 own, without any attribution.                          ++
 ++                                                                        ++
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/**
 * <P>Destructor.</P>
 *
 * <P>Really does not have anything to do in this class.</P>
 *
 * <P>Adding a cout statement during developement can be informative.  Then
 * you will want to comment out the cout statements once large linked lists
 * are added to memory.</P>
 *
 *
 */

MoveOrder::~MoveOrder()
{
    //cout << "Estimate number: " << this->estimateNumber << ",  ";
    //cout << "at address: " << this << " is going out of scope...";
    //cout << endl;
} // END destructor for MoveOrder class


/****************************************************************************
 ****************************************************************************
 **                                   Regular                              **
 **                          function prototypes                           **
 **                                                                        **
 ****************************************************************************
 ****************************************************************************/

void loadFile(string fName, bool &loadSuccess, unsigned long &count, MoveOrder* &head);
void clearLL( unsigned long &count, MoveOrder* &head );
void summaryByType( unsigned long count, MoveOrder* head );
void summaryByRegion( unsigned long count, MoveOrder* head );

/*********************************************************************
 *********************************************************************
 **                 Regular                                         **
 **                 Functions                                       **
 *********************************************************************
 ****************************************************************************
 **                                                                        **
 **                          function loadFile                             **
 **               this function loads the data                             **
 **                                                                        **
 **                                                                        **
 ****************************************************************************
 ****************************************************************************/

void loadFile (string fName, bool &loadSuccess, unsigned long &count, MoveOrder* &head)
{
    //initializing variables
    string State;
    string Region;
    string UniqueID;    //string with no spaces
    string NameAndEmail; //with space
    string fileName = "";
    ifstream inFile;
    string headings = "";
    string oneRow = "";
    
    
    //opening file
    inFile.open(fName.c_str() );
    
    //error message
    if (!inFile)
    {
        cout << ERROR_FILE_OPEN << fName << endl; //file failed to open, error message
        cout << "File data did not successfully load." << endl;
        loadSuccess = false;
        return; //returns to main function
    } //end if statement for infile error
    
    else //processes data
    {
        
        cout << SUCCESS_FILE_OPEN << fName << endl << endl; //file open success message
        getline(inFile, headings); //reading the headings line to get it out of the way
        
        //code to process data starts
        
        //outputting the headings
        cout << right << setw(12) << "Order" << setw(15) << "Move" << setw(13) <<
        "Move"<<setw(10) << "Dist." << setw(10) << "Weight" <<
        setw(10) <<"Number" << setw(10) <<
        "Stairs" << setw(10)<<"Move"<<setw(10) << "Total" << endl;
        
        cout << right << setw(11) << "Date" << setw(16) << "Date" << setw(13) <<
        "Code"<<setw(10) << "(Miles)" << setw(10) << "(LBS)" <<
        setw(10) <<"Pianos"<< setw(5) << "O" << setw(5) <<
        "D" << setw(12)<<"Number"<<setw(11) << "Cost ($)" << endl;
        
        cout << "----------------------------------------------------------";
        cout << "-----------------------------------";
        cout << "----------------------------" << endl;
        
        
        bool answer = true;
        string message = " ";
        int errors = 0; //accumulator
        double totalsales = 0.0;
        int alterrors = 0;
        
        //defining pointer for the head of the linked list
        MoveOrder* mO = new MoveOrder();
        MoveOrder* trace = new MoveOrder();
        unsigned long initialmOsize = count; //keeping track of initial linked list size
        //reading all the rest of the data in
        while(inFile >> mO)
        {
            //cout << "entered the line processing while loop\n";
            //create a node to hold this new object, appending to the beginning of list
            if(head == NULL) //checks if youre at the beginning or end
            {
                //cout << "head was null\n";
                trace = head = mO;
                
            }
            else if(head->getNext()==NULL)
            {
                head->setNext(mO);
                trace = trace->getNext();
            }
            else
            {
                //cout << "head was not null\n";
                //while (trace->getNext() != NULL)
                //{
                    //trace = trace->getNext();
                //}
                trace->setNext(mO);
                trace = trace->getNext();
                //connection of the nodes, adds it to the end of linked list
                //cout << "nodes connected\n";
                count++;
            }
            
            mO->printWithMessages();
            mO->validEstimate(answer, message, errors);
            if (answer == false)
            {
                alterrors++;
            }
            totalsales += mO->getTotalCost();
            
            //cout << "Processing next line.\n";
            
            
        }//END while loop for reading lines and outputting data
        inFile.close();
        
        if (count > initialmOsize)
        {
            loadSuccess = true;
        }
        else
        {
            loadSuccess = false;
        }
        
        
        cout << endl;
        cout << "Total Records: " << count << "  ";
        cout << "Total Records With Errors: " << alterrors << "  ";
        cout << "Total Records Without Errors: "<< count - alterrors << "  ";
        cout << "Total Sales: $" << setprecision(2) << fixed << showpoint << totalsales  <<
        endl << endl;
        
        
    } // end ELSE and data processing
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 ClearLL                                         **
 *********************************************************************
 *********************************************************************/
void clearLL (unsigned long &count, MoveOrder* &head)
{
    MoveOrder *garbage = head;
    while (head != NULL)
    {
        //garbage = head;
        head = head->getNext();
        delete garbage;
        count--;
        garbage = head;
    }
    head = NULL;
    garbage = NULL;
    
    //head = NULL;
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 summarybytype                                   **
 *********************************************************************
 *********************************************************************/
void summaryByType( unsigned long count, MoveOrder* head )
{
    int ccount;
    int total_records = 0;
    int total_distance = 0;
    int total_weight = 0;
    double total_cost = 0;
    
    int total_B_count = 0;
    int total_B_distance = 0;
    int total_B_weight = 0;
    double total_B_cost = 0;
    
    int total_W_count = 0;
    int total_W_distance = 0;
    int total_W_weight = 0;
    double total_W_cost = 0;
    
    int total_C_count = 0;
    int total_C_distance = 0;
    int total_C_weight = 0;
    double total_C_cost = 0;
    
    
    MoveOrder *ptr = head;
    
    for (ccount = 0; ccount < count; ccount++)
    {
        
        bool answer = true;
        string message = "";
        int errors = 0;
        //cout << "before estimate call\n";
        ptr->validEstimate(answer, message, errors);
        //cout << "after estimate call\n";
        if (answer == true)
        {
            cout << "Answer is true\n";
            total_records++;
            total_distance = total_distance + ptr->getDistance();
            total_weight = total_weight + ptr->getWeight();
            total_cost = total_cost + ptr->getTotalCost();
            
            if (ptr->getType() == 'B' || ptr->getType() == 'b')
            {
                
                total_B_count++;
                total_B_distance += ptr->getDistance();
                total_B_weight += ptr->getWeight();
                total_B_cost += ptr->getTotalCost();
            }
            
            if (ptr->getType() == 'W' || ptr->getType() == 'w')
            {
                
                total_W_count++;
                total_W_distance += ptr->getDistance();
                total_W_weight += ptr->getWeight();
                total_W_cost += ptr->getTotalCost();
            }
            
            if (ptr->getType() == 'C' || ptr->getType() == 'c')
            {
                total_C_count++;
                total_C_distance += ptr->getDistance();
                total_C_weight += ptr->getWeight();
                total_C_cost += ptr->getTotalCost();
                
            } //END of if statements
            
            
        }
        
        ptr=ptr->getNext();
    }
    cout << setw(25) << right << "TOTALS ( Correct " << total_records << " records )" << endl;
    cout << setw(10) << left << "Type" << setw(10) << "Count" << setw(10) <<
    "Distance" << setw(10) << "Weight" << setw(10) << "Cost" << endl;
    cout << "-----------------------------------------------------------------------"<< endl;
    cout << setw(10) << left << "Basic" << setw(10) << total_B_count << setw(10) <<
    total_B_distance << setw(10) << total_B_weight << setw(2) << "$" << setw(10) << total_B_cost
    << endl;
    
    cout << setw(10) << left << "Wall Pack" << setw(10) << total_W_count << setw(10) <<
    total_W_distance << setw(10) << total_W_weight << setw(2) << "$" << setw(10) << total_W_cost
    << endl;
    
    cout << setw(10) << left << "Complete" << setw(10) << total_C_count << setw(10) <<
    total_C_distance << setw(10) << total_C_weight << setw(2) << "$" << setw(10) << total_C_cost
    << endl;
    
    cout << "-----------------------------------------------------------------------"<< endl;
    cout << setw(10) << left << "Total" << setw(10) << total_records << setw(10) <<
    total_distance << setw(10) << total_weight << setw(2) << "$" << setw(10) << total_cost
    << endl;
}

/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 summarybyregion                                 **
 *********************************************************************
 *********************************************************************/
void summaryByRegion( unsigned long count, MoveOrder* head )
{
    int errors = 0;
    int ccount;
    int total_records = 0;
    int total_distance = 0;
    int total_weight = 0;
    double total_cost = 0;
    
    int total_South_count = 0;
    int total_South_distance = 0;
    int total_South_weight = 0;
    double total_South_cost = 0;
    
    int total_West_count = 0;
    int total_West_distance = 0;
    int total_West_weight = 0;
    double total_West_cost = 0;
    
    int total_North_count = 0;
    int total_North_distance = 0;
    int total_North_weight = 0;
    double total_North_cost = 0;
    
    int total_East_count = 0;
    int total_East_distance = 0;
    int total_East_weight = 0;
    double total_East_cost = 0;
    
    int total_Other_count = 0;
    int total_Other_distance = 0;
    int total_Other_weight = 0;
    double total_Other_cost = 0;
    
    MoveOrder *ptr = head;
    
    for (ccount = 0; ccount < count; ccount++)
    {
        bool answer = true;
        string message = "";
        total_records++;
        
        ptr->validEstimate(answer, message, errors);
        if (answer == true)
        {
            if (ptr->getRegion() == "South")
            {
                
                total_distance = total_distance + ptr->getDistance();
                total_weight = total_weight + ptr->getWeight();
                total_cost = total_cost + ptr->getTotalCost();
                
                total_South_count++;
                total_South_distance += ptr->getDistance();
                total_South_weight += ptr->getWeight();
                total_South_cost += ptr->getTotalCost();
            }
            
            if (ptr->getRegion() == "West")
            {
                
                total_distance = total_distance + ptr->getDistance();
                total_weight = total_weight + ptr->getWeight();
                total_cost = total_cost + ptr->getTotalCost();
                
                total_West_count++;
                total_West_distance += ptr->getDistance();
                total_West_weight += ptr->getWeight();
                total_West_cost += ptr->getTotalCost();
            }
            
            if (ptr->getRegion() == "North")
            {
                
                total_distance = total_distance + ptr->getDistance();
                total_weight = total_weight + ptr->getWeight();
                total_cost = total_cost + ptr->getTotalCost();
                
                total_North_count++;
                total_North_distance += ptr->getDistance();
                total_North_weight += ptr->getWeight();
                total_North_cost += ptr->getTotalCost();
            }
            
            if (ptr->getRegion() == "East")
            {
                
                total_distance = total_distance + ptr->getDistance();
                total_weight = total_weight + ptr->getWeight();
                total_cost = total_cost + ptr->getTotalCost();
                
                total_East_count++;
                total_East_distance += ptr->getDistance();
                total_East_weight += ptr->getWeight();
                total_East_cost += ptr->getTotalCost();
            }
            
            if (ptr->getRegion() == "Other")
            {
                
                total_distance = total_distance + ptr->getDistance();
                total_weight = total_weight + ptr->getWeight();
                total_cost = total_cost + ptr->getTotalCost();
                
                total_Other_count++;
                total_Other_distance += ptr->getDistance();
                total_Other_weight += ptr->getWeight();
                total_Other_cost += ptr->getTotalCost();
            }
            
            ptr=ptr->getNext();
        }
        
        
        
        
        
    } //END of for loop
    
    cout << setw(25) << right << "TOTALS ( " << total_records << " records )" << endl;
    cout << setw(10) << left << "Region" << setw(10) << "Count" << setw(10) <<
    "Distance" << setw(10) << "Weight" << setw(10) << "Cost" << endl;
    cout << "-----------------------------------------------------------------------"<< endl;
    cout << setw(10) << left << "South" << setw(10) << total_South_count << setw(10) <<
    total_South_distance << setw(10) << total_South_weight << setw(2) << "$" << setw(10)
    << total_South_cost << endl;
    
    cout << setw(10) << left << "West" << setw(10) << total_West_count << setw(10) <<
    total_West_distance << setw(10) << total_West_weight << setw(2) << "$" << setw(10)
    << total_West_cost << endl;
    
    cout << setw(10) << left << "North" << setw(10) << total_North_count << setw(10) <<
    total_North_distance << setw(10) << total_North_weight << setw(2) << "$" << setw(10)
    << total_North_cost << endl;
    
    cout << setw(10) << left << "East" << setw(10) << total_East_count << setw(10) <<
    total_East_distance << setw(10) << total_East_weight << setw(2) << "$" << setw(10)
    << total_East_cost << endl;
    
    cout << setw(10) << left << "Other" << setw(10) << total_Other_count << setw(10) <<
    total_Other_distance << setw(10) << total_Other_weight << setw(2) << "$" << setw(10)
    << total_Other_cost << endl;
    
    cout << "-----------------------------------------------------------------------"<< endl;
    cout << setw(10) << left << "Total" << setw(10) << total_records << setw(10) <<
    total_distance << setw(10) << total_weight << setw(2) << "$" << setw(10) << total_cost
    << endl;
}//END of for loop




/*********************************************************************
 *********************************************************************
 **                                                                 **
 **                 Main                                            **
 *********************************************************************
 *********************************************************************/

int main (int argc, char *argv[])
{
    if (argc != 2) //if there were less/more than two command line arguments
    {
        cout << "ERROR: Please only include executable file name and ONE filepath in the ";
        cout << "command line." << endl;
        exit (0); //terminates without processing
    }
    
    else if (argc == 2) //open file for processing
    {
        //initializing variables
        MoveOrder *head = NULL;
        unsigned long count = 0;
        bool loadSuccess;
        string fName;
        fName = argv[1];
        
        //call loadFile function
        loadFile(fName, loadSuccess, count, head);
        summaryByType(count, head);
        summaryByRegion(count, head );
        clearLL(count, head);
        
        cout << "Thank you for using the BHMSI move cost calculator (Linked List Version)."
        << endl;
        
    }
    
    return 0;
    
} //END int main
